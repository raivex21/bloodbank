﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LendingAppNew
{
    public partial class Form1 : Form
    {
        SqlConnection con = new SqlConnection(@"server = LOCALHOST\SQLEXPRESS; Initial Catalog = lending; Integrated Security = true;");
        SqlCommand cmd;
        SqlDataReader rdr;

        public Form1()
        {
            InitializeComponent();
            LoadClients();
            LoadClient2();
            btnUpdateClient.Enabled = false;
        }
        

        private void ConnectClients()
        {
            dataClient.Rows.Clear();
            con.Open();
            cmd = new SqlCommand("SELECT cID, firstName, midName, lastName, addr, joinDate, sex, addr, contactNum FROM clients;", con);
            rdr = cmd.ExecuteReader();

            while (rdr.Read())
            {
                dataClient.Rows.Add(rdr["cID"].ToString(), rdr["firstName"].ToString(), rdr["midName"].ToString(), rdr["lastName"].ToString(), rdr["joinDate"].ToString(), rdr["sex"].ToString(), rdr["addr"].ToString(), rdr["contactNum"].ToString());
            }
            con.Close();
        }
        private void LoadClients()
        {
            ConnectClients();
        }

        private void btnAddClient_Click(object sender, EventArgs e)
        {
            con.Open();
            cmd = new SqlCommand("INSERT INTO clients (firstName, midName, lastName, addr, joinDate, sex, contactNum) VALUES ('" + txtFirstName.Text + "', '" + txtMidName.Text + "', '" + txtLastName.Text + "', '"+txtAddress.Text+"', '"+DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff") +"', '" + txtSex.Text + "', '" + txtContactNum.Text + "')", con);
            cmd.ExecuteNonQuery();
            con.Close();
            LoadClients();
        }

        private void btnUpdateClient_Click(object sender, EventArgs e)
        {
            con.Open();
            cmd = new SqlCommand("UPDATE clients SET firstName = '"+ txtFirstName.Text + "', midName =  '" + txtMidName.Text + "', lastName = '" + txtLastName.Text + "', addr = '" + txtAddress.Text + "', sex = '" + txtSex.Text + "', contactNum = '" + txtContactNum.Text + "' WHERE cID = '"+txtCID.Text+"'", con);
            cmd.ExecuteNonQuery();
            con.Close();
            LoadClients();
            Clear();
        }

        private void dataClient_SelectionChanged(object sender, EventArgs e)
        {
            if(dataClient.SelectedRows.Count != 0)
            {
                txtCID.Text = dataClient.SelectedRows[0].Cells[0].Value.ToString();
                txtFirstName.Text = dataClient.SelectedRows[0].Cells[1].Value.ToString();
                txtMidName.Text = dataClient.SelectedRows[0].Cells[2].Value.ToString();
                txtLastName.Text = dataClient.SelectedRows[0].Cells[3].Value.ToString();
                txtAddress.Text = dataClient.SelectedRows[0].Cells[6].Value.ToString();
                txtSex.Text = dataClient.SelectedRows[0].Cells[5].Value.ToString();
                txtContactNum.Text = dataClient.SelectedRows[0].Cells[7].Value.ToString();
                btnUpdateClient.Enabled = true;
                btnAddClient.Enabled = false;
            }
        }

        private void btnClearClient_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void Clear()
        {
            txtCID.Clear();
            txtFirstName.Clear();
            txtMidName.Clear();
            txtLastName.Clear();
            txtAddress.Clear();
            txtSex.Clear();
            txtContactNum.Clear();
            btnAddClient.Enabled = true;
            dataClient.ClearSelection();
            btnUpdateClient.Enabled = false;
        }

        private void ConnectClient2()
        {
            dataClient2.Rows.Clear();
            con.Open();
            cmd = new SqlCommand("SELECT cID, firstName, midName, lastName, addr, joinDate, sex, addr, contactNum FROM clients;", con);
            rdr = cmd.ExecuteReader();

            while (rdr.Read())
            {
                dataClient2.Rows.Add(rdr["cID"].ToString(), rdr["firstName"].ToString(), rdr["midName"].ToString(), rdr["lastName"].ToString(), rdr["joinDate"].ToString(), rdr["sex"].ToString(), rdr["addr"].ToString(), rdr["contactNum"].ToString());
            }
            con.Close();
        }

        private void LoadClient2()
        {
            ConnectClient2();
        }
    }
}
