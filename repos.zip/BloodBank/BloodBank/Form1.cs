﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace BloodBank
{
    public partial class Form1 : Form
    {
        SqlConnection con = new SqlConnection(@"server = LOCALHOST\SQLEXPRESS; Initial Catalog = blood; Integrated Security = true;");
        SqlCommand cmd;
        SqlDataReader rdr;




        public Form1()
        {
            InitializeComponent();
            loadBloodbank();
        }

        private void openBloodbank()
        {
            dataPatients.Rows.Clear();
            con.Open();
            cmd = new SqlCommand("SELECT pID, firstName, lastName, middleName, bloodGroup, addr, contactNumber FROM patients;", con);
            rdr = cmd.ExecuteReader();

            while (rdr.Read())
            {
                dataPatients.Rows.Add(rdr["pID"].ToString(), rdr["firstName"].ToString(), rdr["lastName"].ToString(), rdr["middleName"].ToString(), rdr["bloodGroup"].ToString(), rdr["addr"].ToString(), rdr["contactNumber"].ToString());
            }
            con.Close();
        }

        private void loadBloodbank()
        {
            openBloodbank();
        }

    

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
